<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{payme}prestashop>payme_baff0b0835945394af022fcf4ce62832'] = 'Delete ?'; //DELETE_CONFIRM
$_MODULE['<{payme}prestashop>payme_35ba4a2677442e210c23a00a5601aba3'] = 'Payme Business makes it possible to accept payments on your website or through the application, by e-mail or SMS, or at the outlet itself through the contactless payment system and QR code.'; //DESCRIPTION
$_MODULE['<{payme}prestashop>payme_6d26c556b1bdc79cf7d21c4329ebd716'] = 'This module allows you to pay with Payme.'; //MODUL_DESCRIPTION

$_MODULE['<{payme}prestashop>payme_4ce0155bf440038c4df59285e8fd4f53'] = 'Merchant Id'; //PAYME_MERCHANT
$_MODULE['<{payme}prestashop>payme_40473bcfe9e62db9e68b52336f6b5f5f'] = 'Key - checkout password'; //SECURE_KEY
$_MODULE['<{payme}prestashop>payme_462a7d466542be151440d9330282e476'] = 'Key - checkout password for test'; //SECURE_KEY_TEST

$_MODULE['<{payme}prestashop>payme_149a70859728a79c49046a6f40087a4f'] = 'Enable test mode'; //TEST_MODE
$_MODULE['<{payme}prestashop>payme_fbc15f2b00a0d636c0357587ca779ee8'] = 'URL gateway'; //CHECKOUT_URL
$_MODULE['<{payme}prestashop>payme_782ebf0c78f1c52fc8329cbfce7d58f5'] = 'URL gateway for test'; //CHECKOUT_URL_TEST

$_MODULE['<{payme}prestashop>payme_dbf62f7f59c3aea5fd788c43d05dff55'] = 'Redirection URL'; //RETURN_URL
$_MODULE['<{payme}prestashop>payme_8aa48361492e74d5d4aa2cf3f60cb010'] = 'Return after payment'; //RETURN_AFTER
$_MODULE['<{payme}prestashop>payme_3c34ae42280f999fa8e20df7f62ca61b'] = 'Add information about products to check'; //ADD_PRODUCT_INFORMATION
$_MODULE['<{payme}prestashop>payme_7f96e80043890d3c65052f934a42bdaf'] = 'Endpoint Url. This URL must be entered setting of cashier in personal cabinet of Merchant'; //ENDPOINT_URL

$_MODULE['<{payme}prestashop>payme_e3e7558e4e1f2ec16590173ded7b1c8f'] = 'Instantly'; //INSTANTLY
$_MODULE['<{payme}prestashop>payme_74a21b5dd9b92ad1e11f2f39f34a4394'] = '15 seconds'; //S15
$_MODULE['<{payme}prestashop>payme_c317634f2e2547e5909e87d80dd62c6e'] = '30 seconds'; //S30
$_MODULE['<{payme}prestashop>payme_daf759c6ceddc3e56dd0f1d00dc43a01'] = '60 seconds'; //S60 

$_MODULE['<{payme}prestashop>payme_7469a286259799e5b37e5db9296f00b3'] = 'Yes';  //YES
$_MODULE['<{payme}prestashop>payme_c2f3f489a00553e7a01d369c103c7251'] = 'No'; //NO 

$_MODULE['<{payme}prestashop>payme_f5cf47ab06d0d98b0d16d10c82d87953'] = 'Save'; //SAVE
$_MODULE['<{payme}prestashop>payme_ed6f7aca7887a927b9ed3d62aa347a86'] = 'Settings'; //SETTINGS

$_MODULE['<{payme}prestashop>payme_174db26d09c8ab671d6695ff5404db62'] = 'Pay with Payme'; //PAY_WITH_PAYME